#' dbdisconnectall
#' 
#' @description function to close all current PostgreSQL db connections
#' @export
#' @examples
#' dbdisconnectall()

dbdisconnectall <- function(){
  ile <- length(dbListConnections(PostgreSQL())  )
  lapply( dbListConnections(PostgreSQL()), function(x) dbDisconnect(x) )
  cat(sprintf("%s connection(s) closed.\n", ile))
}
