#' tidytext
#' 
#' @description This function trims white space, makes text upper case and replaces any space with underscore
#' @param x, A vector
#' @return A merged dataframe as per parameters entered
#' @export
#' @examples
#' tidytext(x)

#-- function to clear up text, particularly tumour types.
#- trims white space, makes upper space, then replaces any space with underscore
tidytext <- function(x){
  gsub("[[:space:]]+", "_",
       toupper(
         trimws(x)
       )
  )
}