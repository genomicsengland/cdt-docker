
#' plot_theme
#'
#' @description A function to bring in the CDT standard ggplot2 plot theme as a variable
#' @return A variable specifying ggplot2 plot aesthetics 
#' @export
#' @examples
#' plot_theme()


plot_theme  <-  function() {
require(ggplot2)
plotTheme <<- theme(plot.title=element_text(size=12, face="bold", colour="#424857", hjust=0.5, vjust=2),
                   legend.position="none",
                   axis.text.x  = element_text(vjust=0.5, size=9, colour="#424857"),
                   axis.text.y  = element_text(size=9, colour="#424857"),
                   axis.line.x = element_line(size=0.5, color="#696b7a"),
                   axis.line.y = element_line(size=0.5, color="#696b7a"),
                   axis.line = element_line(size=.75, color="#424857"),
                   axis.ticks.x = element_line(color="#444759"),
                   axis.ticks.y = element_line(color="#444759"),
                   axis.title = element_text(size=11, colour="#424857"),
                   panel.grid.major = element_blank(), 
                   panel.grid.minor = element_blank(),
                   panel.background = element_rect(fill = "transparent",colour = NA), 
                   plot.background = element_rect(fill = "transparent",colour = NA),
                   panel.border=element_blank(),
                   strip.text.x = element_text(size=11, colour="#424857", face="bold"),
                   strip.text.y = element_text(size=12, face="bold"),
                   strip.background = element_rect(fill="transparent", colour=NA))
}

