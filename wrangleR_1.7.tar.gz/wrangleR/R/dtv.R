#' dtv
#'
#' @description a function to view the contents of a dataframe (or table, vector, or list of dataframes) in a datatable viewer
#' @param indf, the dataframe, table, vector or matrix (less than 3 dimensions), or list of dataframes to be viewed
#' @param dfname, the name of the dataframe that appears as a caption above the table
#' @return a data.table view of input dataframe in a browser window
#' @export
#' @examples
#' dtv(mtcars)
#' dtv(table(mtcars$cyl, mtcars$gear))

dtv <- function(indf, dfname = ""){
	require(DT)
	#-- the viewer function
	v <- function(df, name){
		datatable(df,
			  filter = 'top', # get filter boxes at top
			  class = 'cell-border stripe', # get stripes to show rows and columns
			  options = list(
					 pageLength = 25, # have 25 rows per page as default 
					 lengthMenu = c(25, 100, 1000, -1), # options for page length, -1 = all
					 autoWidth = TRUE,
					 fixedHeader = T,
					 buttons = c("copy", "excel", "csv"), #add buttons
					 dom = 'lfrtBip' #sequence of elements
					 ),
			extensions = c("FixedHeader", "Buttons"), # Fixed Header keeps column headers at top when scrolling, Buttons give download options
			caption = name # put the name of the dataframe top center of page
		)
	}
	#-- if no name of df is supplied then default to the object name of the dataframe
	dfname <- ifelse(dfname == "", deparse(substitute(indf)), dfname)
	#-- do the different views based on what indf is
	if(is.vector(indf) & !is.list(indf)){
		outdf <- data.frame("vector" = indf)
		print(v(outdf, dfname))
	}
	else if(is.table(indf)){
		if(length(dim(indf)) == 1){
			outdf <- as.data.frame(as.matrix(indf))
		} else if (length(dim(indf)) == 2) {
			outdf <- as.data.frame.matrix(indf)
		} else {
			stop("Too many dimensions in the table")
		}
		print(v(outdf, dfname))
	}
	else if(is.matrix(indf)){
		if(length(dim(indf)) < 3){
			outdf <- as.data.frame(indf)
		} else {
			stop("Too many dimension in the matrix")
		}
		print(v(outdf, dfname))
	}
	else if("data.frame" %in% class(indf)){
		print(v(indf, dfname))
	}
	else if(is.list(indf) & all(sapply(indf, class) == "data.frame")){
		for(i in names(indf)){
			print(v(indf[[i]], i))
			readline(prompt = paste("Viewing", i, "<Enter> for next df..."))
		}
	}
	else {
		stop("Data not in a form presentable by datatable")
	}
}
