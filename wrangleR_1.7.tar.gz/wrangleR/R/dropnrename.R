#' dropnrename
#'
#' @description This function allows you to specify the vectors to subset by and also rename them within the same statement
#' @param df, A dataframe or matrix
#' @param keepcols, A vector containing columns you want to keep from df
#' @param newnames, A vector containing the new names for the columns you want to keep
#' @return A subsetted dataframe with new vector headers
#' @export
#' @examples
#' dropnrename(df, c("column1","column2","column4"), c("col1","col2","col4"))

#-- function to specify which columns to keep and what to rename them to
dropnrename <- function(df, keepcols, newnames){
  #-- bug out if keepcols and newnames not same length
  stopifnot(length(keepcols) == length(newnames))
  #-- function to do basic dropping and renaming of columns
  df <- df[,keepcols]
  #-- bug out if didn't remove columns properly
  stopifnot(length(keepcols) == ncol(df))
  #-- assign new names
  names(df) <- newnames
  #-- remove duplicate rows in cut down dataframe
  return(unique(df))
}

