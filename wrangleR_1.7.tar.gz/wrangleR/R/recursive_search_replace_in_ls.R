recursive_search_replace_in_ls <- function(x, s, r){
	#-- helper function for getprofile to search and replace recursively in list
    if(length(s) != length(r)){
        stop("s and r must be same length")
    }
    if(is.list(x)){
        lapply(x, function(y) recursive_search_replace_in_ls(y, s, r))
    } else {
        for(i in 1:length(s)){
            x <- gsub(s[i], r[i], x)
        }
        return(x)
    }
}
