#' dedupdf
#'
#' @description A function to take in df and aggregate where there are duplicate records for a single individual.
#' @param x, A dataframe 
#' @return A deduplicated dataframe with a unique patient identifier per row, where value is different it is concatenated to same string
#' @export
#' @examples
#' dedupdf(df)

#-- function to take in df and aggregate where there are duplicate records for a single individual.
#e.g. if two different clinics found for a participant, then returns clin1;clin2 on a single line for that participant
dedupdf <- function(df, identifier = "participant_identifiers_id"){
  # stop if identifier isn't a colname
  stopifnot(any(identifier %in% names(df)))
  df <- unique(df)
  # which are the genuinely unique rows
  uniq <- which(!(duplicated(df[[identifier]]) | duplicated(df[[identifier]], fromLast = TRUE)))
  if(nrow(df) != length(uniq)){
    print(paste(nrow(df) - length(uniq), "duplicated records found, collapsing some records"))
    uniqdf <- df[uniq,]
    dupdf <- df[-uniq,]
    # for each of the duplicated rows, paste together the duplicates
    dupdfagg <- aggregate(formula(paste(". ~", identifier)),
                          data = dupdf,
                          function(x) paste(as.character(x), collapse = ";"))
    return(rbind(uniqdf, dupdfagg))
  } else {
    return(df)
  }
}