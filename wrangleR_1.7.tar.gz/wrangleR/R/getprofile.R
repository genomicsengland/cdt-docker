#' getprofile
#' 
#' @description function to get profile and connection configurations from .gel_config
#' @param items the objects within the config file to be returned. Must be one of the first level items in the file. If none specified the entire contents minus .defaults is returned as a list.
#' @param file the config file to read from. Defaults to ~/.gel_config.
#' @param silent default TRUE. Should the name of the profile be printed.
#' @return a list containing the relevant portions of the config file (or all of it if no items are specified)
#' @export
#' @examples
#' getprofile(c("mis_con", "dams_con"))
#' getprofile("mis_con")
#' getprofile()

getprofile <- function(items = NULL, file = "~/.gel_config", silent = TRUE){
    require(jsonlite)
    #-- stop if file doesn't exist
	if(!file.exists(file)){
		stop(paste("File", file, "not found"))
	}
    x <- fromJSON(file)
    p <- x[["profile"]]
    #-- if no items specified then give everything apart from defaults
    if(is.null(items)){
        items <- names(x)[!names(x) %in% ".defaults"]
    }
	#-- stop if any of the items aren't in the profile
	if(any(!items %in% names(x))){
		stop("Not all items found in profile")
	}
    #-- fill out defaults
    x <- fill_profile_defaults(x)
    #-- say which profile we read from
	if(!silent & !is.null(p)){
		cat(paste("Read from", p, "profile\n"))
	} else if(!silent){
		cat(paste("Read from", file, "- no profile specified\n"))
	}
	#-- if just a single item requested, return just that item, otherwise return list of items
	if(length(items) == 1){
        return(x[[items]])
    } else {
        return(x[items])
    }
}
