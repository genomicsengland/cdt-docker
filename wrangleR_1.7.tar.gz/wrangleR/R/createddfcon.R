#' createddfcon
#' 
#' @description function to create connection to specific ddf database
#'
#' @param cn, connection name; the name of the connection object you want to create. Connection objects seem to have to be in the global environment to work correctly, so the function creates an object in the global environment.
#' @param dbn, the name of the ddf database to which the connection should be made
#' @return a PostgreSQL connection object (with name as specified in cn parameter) is created in the global environment
#' @export
#' @examples
#' ddfconnect("cdr.con", "central_data_repo")

createddfcon <- function(cn, dbn){
	require(RPostgreSQL)
	connectdeets <- data.frame(
		"dbname" = c("api_caller_db", "data_capture_repo", "clean_data_repo", "data_delivery_repo", "data_modelling_repo", "central_data_repo", "delta_engine_repo", "rules_engine_db", "labkey"),
		"host" = c("127.0.0.1"),
		"port" = c(rep(5435, 8), 5434),
		"user" = c("ddf-apicaller", "ddf-datacapture", "ddf-datacleaning", "ddf-datadelivery", "ddf-datamodelling", "ddf-datastore", "ddf-deltaengine", "ddf-rulesengine", "ddf"),
		"password" = c("hee0Ohxoikeo", "buuCie3rii2O", "aebae3Siemie", "vahcee5Eu1th", "aiN9taiph2ei", "ibeaX8aiMoh3", "se8ahdeeTeid", "kohh5Vooquee", "La81ah9aVWEkAL12"),
		stringsAsFactors = F
		)
	drv <- dbDriver("PostgreSQL")
	if(!dbn %in% connectdeets$dbname | length(dbn) != 1){
		stop(paste(dbn, "not a ddf db, they are", paste(connectdeets$dbname, collapse = "; ")))
	} else {
		x <- which(dbn %in% connectdeets$dbname)
		assign(cn, dbConnect(drv,
				 dbname = connectdeets$dbname[x],
				 host = connectdeets$host[x],
				 port = connectdeets$port[x],
				 user = connectdeets$user[x],
				 password = connectdeets$password[x]
				 ),
		       envir = .GlobalEnv)
	}
}
