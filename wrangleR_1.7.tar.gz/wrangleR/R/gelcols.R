
#' gelcols
#'
#' @description A function to create the Genomics England colour scheme hex codes as variables 
#' @return A variables specifying hex codes according to the GeL branding guidelines  
#' @export
#' @examples
#' gelcols()
#'
#' Colours you can then define are as follows:
#' 
#' Primary Pallette:
#' gelbl = gel blue
#' gellbl = gel light blue
#' gelgr = gel green
#'
#' Secondary Pallette:
#' gelor = gel orange
#' gellor = gel light orange
#' gelgry = gel gray
#' gellgry = gel light gray
#' geltq = gel turquoise
#' gelltq = gel light turquoise

gelcols  <-  function() {
gelbl <<- "#27B7CC"
gellbl <<- "#ADDCE9"
gelgr <<- "#90c684"
gelor <<- "#D3922D"
gellor <<- "#EDC79A"
gelgry <<- "#44546b"
gellgry <<- "#9FA7B3"
geltq <<- "#0EAD84"
gelltq <<- "#7BD4C0"
}                


