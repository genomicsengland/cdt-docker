
#' plotly_theme
#'
#' @description A function to bring in the CDT standard ggplot2 plotly theme as a variable
#' @return A variable specifying ggplot2 plotly aesthetics 
#' @export
#' @examples
#' plot_theme()


plotly_theme  <-  function() {
require(ggplot2)
require(plotly)
plotlyTheme <<- theme(plot.title=element_text(size=14, face="bold", colour="#424857", hjust=0.5, vjust=2),
                    legend.position="none",
                    axis.text.x  = element_text(vjust=0.5, size=9, colour="#424857"),
                    axis.text.y  = element_text(size=9, colour="#424857"),
                    axis.line.x = element_line(size=1.25, color="#696b7a"),
                    axis.line.y = element_line(size=1.25, color="#696b7a"),
                    axis.line = element_line(size=.75, color="#424857"),
                    axis.ticks.x = element_line(color="#444759"),
                    axis.ticks.y = element_line(color="#444759"),
                    axis.title = element_text(size=11, colour="#424857"),
                    panel.grid.major = element_blank(), 
                    panel.grid.minor = element_blank(),
                    panel.background = element_rect(fill = "transparent",colour = NA), 
                    plot.background = element_rect(fill = "transparent",colour = NA),
                    panel.border=element_blank())
}                


