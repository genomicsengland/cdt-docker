#' Retrieve the upload report
#' 
#' returns the upload report as a data.frame (removing the comments at top).
#' Accesses \url{https://upload-reports.gel.zone/upload_report.latest.txt}
#' Requires connection to the bioinformatics VPN.
#' @export
#' @examples
#' d <- getur()
getur <- function(){
	require(RCurl)
	read.table(textConnection(getURL('https://upload-reports.gel.zone/upload_report.latest.txt')),
			sep = "\t",
			col.names = c("No",
				"Type",
				"Platekey",
				"DeliveryID",
				"Delivery.Date",
				"Path",
				"BAM.Date",
				"BAM.Size",
				"Status",
				"Delivery.Version"),
                          comment.char = "#",
			  stringsAsFactors = F
	)
}
