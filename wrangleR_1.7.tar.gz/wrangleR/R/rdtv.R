#' rdtv
#'
#' @description A function to display a randow set of rows from a dataframe, vector of list of dataframes in a datatable view
#' @param indf, the dataframe (or vector or list) to be viewed
#' @param nr, the number of randomly selected rows we want to view, defaults of 100
#' @return a datatable view of a random set of rows from the input dataframe
#' @export
#' @examples
#' rdtv(mtcars, 20)

rdtv <- function(indf, nr = 100){
	rr <- function(l, r){
		sample(1:l, min(r, l))
	}
	if(is.data.frame(indf)){
		dtv(indf[rr(nrow(indf), nr), ], "Rando")
	}
	else if(is.list(indf) & all(sapply(indf, class) == "data.frame")){
		outdf <- lapply(indf, function(x){x[rr(nrow(x), nr), ]})
		for(i in names(outdf)){
			dtv(outdf[[i]], "Rando")
			readline(prompt = paste("Viewing", i, "<Enter> for next df..."))
		}
	}
	else if(is.vector(indf)){
		outdf <- data.frame("vector" = indf[rr(length(indf), nr)])
		dtv(outdf, "Rando")
	}
	else {
		stop("Data not in a form suitable for randomisation/presentation")
	}
}
