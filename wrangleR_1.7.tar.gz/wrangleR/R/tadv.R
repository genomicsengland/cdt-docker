#' tadv
#'
#' @description a function to view the contents of a dataframe in Tad
#' @param indf, the dataframe
#' @return a Tad window showing the contents of the dataframe
#' @export
#' @examples
#' tadv(mtcars)

tadv <- function(indf){
	if(class(indf) != "data.frame"){
		stop("Data must be a dataframe")
	}
	#-- get the name of the dataframe and create a unique filename in tempfolder
	fn <- paste0(tempdir(), "/", deparse(substitute(indf)), "-", round(as.numeric(Sys.time()) * 10))
	#-- write out data then open in Tad
	write.csv(indf, fn)
	system(paste("tad", fn))
}
