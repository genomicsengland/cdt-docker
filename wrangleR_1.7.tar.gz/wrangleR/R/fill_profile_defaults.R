fill_profile_defaults <- function(x){
	#-- helper function for getprofile to fill out defaults in profile
    defaults <- unlist(x$.defaults)
    recursive_search_replace_in_ls(x, paste0("^!", names(defaults), "!$"), defaults)
}
