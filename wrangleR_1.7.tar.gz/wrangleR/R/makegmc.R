#' makegmc 
#' 
#' @description A function to create gmc from the opening three digits of the participant ID
#'
#' @param x, a vector within a dataframe
#' @param abbrev, logical, default is FALSE, whether abbreviated GMC names should be returned
#' @param devnat, logical, default is TRUE, whether the devolved nation GMCs should be included in the returned values
#' @param misval, default is "No GMC", value that should be assigned to IDs that are not attributable to a GMC
#' @return A vector of GMC names corresponding to the id numbers supplied
#' @export
#' @examples
#' makegmc(c("123456789", "0", "1234567", NA, "999999999", "112123456"), devnat = F)

#-- function to make GMC from participant ID
makegmc <- function(id, abbrev = FALSE, devnat = TRUE, misval = "No GMC"){
	#-- check abbrev and devnat are logical
	stopifnot(all(sapply(c(abbrev, devnat), class) == "logical"))
	#--define prefix:GMC dataframe
	gmcprefix <- data.frame(
		"prefix" = c("111", "112", "113", "114", "115", "116", "117", "118", "119", "120", "210", "121", "122", "211", "212", "213", "214", "215", "216", "217", "218", "219", "220", "221", "222", "223", "128", "228", "123", "124", "125", "224", "225", "226"),
		"GMC" = c("East of England", "South London", "Greater Manchester", "North East and Cumbria", "North Thames", "North West Coast", "Oxford", "South Coast", "South West Peninsula", "West London", "West Midlands", "West of England", "Yorkshire and Humber", "East of England", "South London", "Greater Manchester", "North East and Cumbria", "North Thames", "North West Coast", "Oxford", "South Coast", "South West Peninsula", "West London", "West Midlands", "West of England", "Yorkshire and Humber", "South London", "South London", "Wales", "Northern Ireland", "Scotland", "Wales", "Northern Ireland", "Scotland"), 
		"GMCAbbrv" = c("EofE", "SLo", "GrMan", "NEC", "NoT", "NWC", "Ox", "SoCo", "SWP", "WLo", "WMid", "WofE", "Y&H", "EofE", "SLo", "GrMan", "NEC", "NoT", "NWC", "Ox", "SoCo", "SWP", "WLo", "WMid", "WofE", "Y&H", "SLo", "SLo", "Wal", "NIre", "Sco", "Wal", "NIre", "Sco"),
		"DevNat" = c(rep(FALSE, 28), rep(TRUE, 6)), stringsAsFactors = F
		)
	#-- change dataframe depending on whether devolved nations and abbreviations are needed
	if(abbrev == TRUE){
		gmcprefix <- gmcprefix[,-2]
	}
	if(devnat == FALSE){
		gmcprefix <- gmcprefix[!gmcprefix$DevNat,]
	}
	#-- don't want to be looking at factors or other stuff
	stopifnot(class(id) %in% c("character", "numeric", "integer"))
	#-- get first three digits of the 9 digit participant id
	prefix <- floor(as.integer(id) / 1000000)
	gmc <- rep(NA, length(prefix))
	#-- iterate of each prefix
	for(i in gmcprefix$prefix){
		gmc[prefix == i] <- gmcprefix[gmcprefix$prefix == i,2]
	}
	#-- replace NAs with misval
	gmc[is.na(gmc)] <- misval
	return(gmc)
}
