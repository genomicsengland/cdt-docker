#' multimerge
#'
#' @description A function to merge 2 or more dataframes based on the same value
#' @param dflist, A list of dataframes you want to join
#' @param mergecol, The vector by which you want to join the dataframes
#' @return A merged dataframe as per parameters entered
#' @export
#' @examples
#' multimerge(list(df1,df2, df3, df4, df5),"id")


#-- function to merge multiple dataframes
multimerge <- function(dflist, mergecol){
  #-- check mergecol in each of the dfs
  stopifnot(all(sapply(dflist, function(x) mergecol %in% names(x))))
  #-- merge everything
  outdf <- Reduce(function(df1, df2) merge(df1, df2, by = mergecol, all = T),
                  dflist)
  return(outdf)
}
