#' getlkdata
#'
#' @description This function is a less verbose method of bringing in data from Labkey. NOTE: requires Rlabkey package. The required fpath, schema, and query can be got by using the Export>R script option within the LabKey table view. The default colnamingoption is fieldname which is generally what you get if you hover over the column heading. However, this is not always the case. It may require experimentation for each table to find the correct names for specific columns. Note the default is to return a unique dataframe, removing duplicate rwos
#' @param url, LK URL containing required data
#' @param fpath, The folder path containing required LK view
#' @param schema, The schema the required LK view is contained within
#' @param query, The name of the query which outputs the required LK view
#' @param cols, the columns you require from the specified LK view
#' @param uniquefy, whether the dataframe returned from LK should have duplicate rows removed or not (default is TRUE)
#' @return A dataframe containing data specified within the getlkdata function request
#' @export
#' @examples
#' getlkdata( "https://gmc.genomicsengland.nhs.uk//labkey", "/Genomics England Portal/All Patients/MeRCURy/Cancer/Core", "gel_cancer", "participant_identifier", c("participant_id", "date_of_birth"))

#-- function to simplify reading the calls to LabKey
getlkdata <- function(url, fpath, schema, query, cols = "", nareplace = NA, view = NULL, colnamingoption = 'fieldname', incldispval = TRUE, uniquefy = TRUE){
  require('Rlabkey')
  data <- labkey.selectRows(
    baseUrl=url,
    folderPath=fpath,
    schemaName=schema,
    queryName=query,
    colSelect=cols,
    colNameOpt = colnamingoption,
    viewName = view,
    includeDisplayValues = incldispval
  )
  ifelse(ncol(data) < length(cols),
         print(paste0("WARNING: mismatch in cols requested and received - ", query)),
         print(paste("Got", nrow(data), "rows from", query))
  )
  data[is.na(data)] <- nareplace
  if(uniquefy == TRUE){
    return(unique(data))
  } else {
    return(data)
  }
}
