#' duplicateview
#'
#' @description function to view in a datatable view the duplicate rows within a dataframe
#' @param df, the dataframe to be viewed
#' @param col, the column in which duplicates will be looked for
#' @param ignoreNA, should we looked for duplicate NAs too? Default is yes
#' @return a datatable view of dataframe, filtered for the duplicate rows in the specified column of the dataframe
#' @export
#' @examples
#' duplicateview(mtcars, "mpg")

duplicateview <- function(df, col, ignoreNA = TRUE){
	i <- which(colnames(df) %in% col) #get the column index
	stopifnot(length(i) == 1) #check that column specified is in the dataframe
	stopifnot(class(ignoreNA) == "logical") #check that ignoreNA is valid
	if(ignoreNA == TRUE){ # if we're including NAs
		dups <- which(
			      (duplicated(df[[i]]) | duplicated(df[[i]], fromLast = TRUE)) #get the indices for duplicate rows
			       & !is.na(df[[i]]) #which are not NA
			      )
		print(paste0(length(dups), "/", nrow(df), " duplicated rows; ", sum(is.na(df[[i]])), " NAs ignored")) #output how many rows are duplicated
	}
	if(ignoreNA == FALSE){ # if we're not ignoring NAs
		dups <- which(duplicated(df[[i]]) | duplicated(df[[i]], fromLast = TRUE)) #look for all duplicate rows (which will also return any duplicate NA values)
		print(paste0(length(dups), "/", nrow(df), " duplicated rows")) # how many rows are we looking at
	}
	dtv(df[dups,]) #use dtv function to view just the rows we're interested in
}
