# wrangleR

### Synopsis

The _wrangleR_ package brings together the user-defined functions used regularly by the Clinical Data Team data wranglers.

Current version: **1.7**

Included functions are as follows:
  * _age_
  * _createddfcon_
  * _dbdisconnectall_
  * _dedupdf_
  * _dropnrename_
  * _dtv_
  * _duplicateview_
  * _gelcols_
  * _getlkdata_
  * _getprofile_
  * _getur_
  * _makegmc_
  * _multimerge_
  * _plot_theme_
  * _plotly_theme_
  * _rdtv_
  * _tidytext_
  * _tadv_

Each function has been documented within the package itself using _roxygen2_.

### Installation

To install either:

  * Download this folder from this repository and run `devtools::build("wrangleR")` on the folder (requires _devtools_ package) and then install the resulting _tar.gz_ file (`install.packages(<path_to_file>, repos = NULL, type = "source"`)
  * Install using the wrangleR `tar.gz` file found on the Clinical Data Team [Huddle space](https://my.huddle.net/workspace/38436681/files/#/folder/45401246/list)

### Contributors
Simon Thompson, Michael Walker

### TODO

_N/A_
